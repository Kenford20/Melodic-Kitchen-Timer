/*
 * rotary.h
 *
 *  Created on: Oct 15, 2016
 *      Author: Kenny Zhou
 */

#ifndef ROTARY_H_
#define ROTARY_H_

void rotaryInit();

int ADCinit();


#endif /* ROTARY_H_ */
